package dicoding.mobileprogramming.faishalammar.imdc.di

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class AppScope