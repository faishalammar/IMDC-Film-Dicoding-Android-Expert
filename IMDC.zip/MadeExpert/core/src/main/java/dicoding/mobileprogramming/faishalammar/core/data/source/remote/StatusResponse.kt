package dicoding.mobileprogramming.faishalammar.core.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}