package dicoding.mobileprogramming.faishalammar.core.utils.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}