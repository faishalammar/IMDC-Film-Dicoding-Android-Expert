package dicoding.mobileprogramming.faishalammar.imdc.favourites.di

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.SOURCE)
annotation class FavouriteScope